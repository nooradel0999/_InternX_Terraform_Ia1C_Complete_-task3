Terraform IaC - 20 uniform professional images
Canvas: 1600x900 PNG, consistent header, border, spacing.

01_production_ready_aws_terraform.png
  Stage: Production-ready AWS with Terraform
  Source file: 10_Final_project_Terraform_AWS_Infrastructure.png

02_hcl_write_init_plan_apply_state.png
  Stage: HCL workflow: write, init, plan, apply, state
  Source file: 1_From_Zero_to_Production_Build_Scalable.png

03_two_tier_wordpress_terraform.png
  Stage: Two-tier AWS architecture with Terraform
  Source file: 2_Terraform_HCL_HashiCorp_Configuration.png

04_iac_vcs_provider_state.png
  Stage: IaC with VCS, provider, and state management
  Source file: 3_Deploy_WordPress_on_a_2_Tier_AWS.png

05_terraform_cli_workflow.png
  Stage: Terraform workflow: init, validate, plan, apply, destroy
  Source file: 4_Getting_Started_with_Terraform_A.png

06_vpc_ec2_rds_mysql_terraform.png
  Stage: VPC with EC2 and MySQL RDS via Terraform
  Source file: 5_Terraform_Work_Flow_GeeksforGeek.png

07_vpc_subnets_internet_nat.png
  Stage: VPC subnets, routing, internet and NAT access
  Source file: 6_Creating_AWS_MySQL_RDS_and_EC2_with.png

08_terraform_core_providers_state.png
  Stage: Terraform core, plugins, providers, and state
  Source file: 7_What_is_Subnet_on_AWS_VPC_DEV_Communit.png

09_vpc_route_tables_terraform.png
  Stage: VPC route tables and subnet routing
  Source file: 8_Terraform_Architecture_Overview_Structure.png

10_multi_az_public_private_data.png
  Stage: Multi-AZ public/private/data subnets
  Source file: 9_AWS_VPC_Subnets_Routing_Tables_and.png

11_s3_dynamodb_remote_backend.png
  Stage: S3 and DynamoDB remote backend module
  Source file: 10_Terraform_Architecture_Overview_Structure.png

12_variable_driven_environments.png
  Stage: Variable-driven configurations
  Source file: 1_Creating_a_Terraform_Module_for_S3.png

13_s3_backend_state_locking.png
  Stage: S3 backend with state locking
  Source file: 2_Multi_Environment_Terraform_Dev_Staging.png

14_remote_backend_lock_acquired.png
  Stage: Remote backend and state lock flow
  Source file: 3_Creating_a_Terraform_Module_for_S3.png

15_terraform_data_pipeline_outputs.png
  Stage: Terraform-managed AWS data pipeline
  Source file: 4_Terraform_Backend_Explained_S3_State.png

16_dev_staging_prod_promotion.png
  Stage: Dev, staging, and production promotion
  Source file: 5_Building_a_Serverless_Real_Time_Data.png

17_remote_state_datasource_projects.png
  Stage: Remote state data source across projects
  Source file: 6_Multi_Environment_Terraform_Dev_Staging.png

18_s3_encryption_versioning_locking.png
  Stage: S3 encryption, versioning, and locking
  Source file: 7_Terraform_Remote_State_Datasource.png

19_workspaces_vs_directories.png
  Stage: Workspaces vs directory separation
  Source file: 8_How_to_use_s3_backend_with_a_locking.png

20_terraform_architecture_summary.png
  Stage: Terraform architecture summary
  Source file: 9_Multi_Environment_Terraform_Dev_Staging.png

